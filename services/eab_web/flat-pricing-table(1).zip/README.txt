A Pen created at CodePen.io. You can find this one at http://codepen.io/vivek-kumar/pen/KoLwz.

 Its an HTML version of the dribble shot http://dribbble.com/shots/1285240-Freebie-Flat-Pricing-Table?list=tags&tag=pricing_table